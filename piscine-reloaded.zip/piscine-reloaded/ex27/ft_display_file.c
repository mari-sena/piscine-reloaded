/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mariafer <mariafer@student.42sp.org.br>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/05/13 14:33:19 by mariafer          #+#    #+#             */
/*   Updated: 2026/05/13 14:33:22 by mariafer         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <fcntl.h>

void	ft_putchar(char *str)
{
	while (*str)
		write(1, str++, 1);
}

int	main(int argc, char *argv[])
{
	int		fd;
	char	fc;

	if (argc == 1)
		ft_putchar("File name missing.");
	if (argc > 2)
		ft_putchar("Too many arguments.");
	if (argc == 2)
	{
		fd = open(argv[1], O_RDONLY);
		if (fd == -1)
		{
			ft_putchar("File name not found.");
			return (-1);
		}
		while (read(fd, &fc, 1) > 0)
			ft_putchar(&fc);
		close(fd);
		return (0);
	}
	return (1);
}
